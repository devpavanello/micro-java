package br.com.fiap.produtomvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutoMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
