package br.com.fiap.mvcusuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
