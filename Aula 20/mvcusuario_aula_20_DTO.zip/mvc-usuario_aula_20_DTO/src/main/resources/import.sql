INSERT INTO tb_user(nome, email, data_nascimento, senha, moment) VALUES ('Maria de Jesus', 'maria@gmail.com',  '1999-05-21', '96547812', TIMESTAMP WITH TIME ZONE '2020-07-25T13:00:00Z' );
INSERT INTO tb_user(nome, email, data_nascimento, senha, moment) VALUES ('Pedro Alcantara', 'pedro@gmail.com', '1987-12-05', '78451236', TIMESTAMP WITH TIME ZONE '2022-07-29T15:50:00Z');
INSERT INTO tb_user(nome, email, data_nascimento, senha, moment) VALUES ('José da Silva', 'js@gmail.com', '2002-01-30', '12345678', TIMESTAMP WITH TIME ZONE '2023-08-03T14:20:00Z');
