package br.com.fiap.mvcusuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcUsuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcUsuarioApplication.class, args);
	}

}
